import joblib
import pandas as pd
from fastapi import FastAPI
from pydantic import BaseModel
from typing import Optional

# 1. Define el esquema de entrada (los datos que recibe la API)
#    Esto debe coincidir con las columnas que tu pipeline espera ANTES del preprocesamiento.
class ModelInput(BaseModel):
    Gender: str
    Age: int
    Occupation: str
    Sleep_Duration: float  # Renombrado con _ por Pydantic/JSON
    Physical_Activity_Level: int
    Stress_Level: int
    BMI_Category: str
    Blood_Pressure: str  # Ej: "126/83"
    Heart_Rate: int
    Daily_Steps: int
    Sleep_Disorder: Optional[str] = None # Opcional, puede ser null

    # Pydantic usa alias para mapear JSON (con _) a Pandas (con espacio)
    class Config:
        alias_generator = lambda string: string.replace("_", " ")
        allow_population_by_field_name = True

# 2. Inicializa la API
app = FastAPI(title="API de Calidad del Sueño", version="1.0")

# 3. Carga el pipeline (¡solo una vez!)
# La ruta es relativa a donde se ejecuta gunicorn (desde la raíz del proyecto)
try:
    pipeline = joblib.load('model-pkg/sleep_quality_pipeline.joblib')
except FileNotFoundError:
    pipeline = None
    print("Error: Archivo 'sleep_quality_pipeline.joblib' no encontrado.")


# 4. Define el endpoint de predicción
@app.post("/predict")
def predict(data: ModelInput):
    if pipeline is None:
        return {"error": "Modelo no cargado. Revisa la ruta o los logs."}

    # --- Replicar la lógica de limpieza del Notebook ---
    # Convierte la entrada Pydantic a un diccionario
    input_dict = data.dict(by_alias=True) # Usa los alias (con espacios)

    # a) Rellenar NaNs (JSON 'null' se vuelve None)
    if input_dict['Sleep Disorder'] is None:
        input_dict['Sleep Disorder'] = 'No Sleep Disorder'

    # b) Dividir 'Blood Pressure'
    try:
        bp_split = input_dict['Blood Pressure'].split('/')
        input_dict['Systolic Pressure'] = int(bp_split[0])
        input_dict['Diastolic Pressure'] = int(bp_split[1])
    except Exception as e:
        return {"error": f"Error procesando Blood Pressure: {str(e)}"}
    
    # --- Convertir a DataFrame ---
    # El pipeline espera un DataFrame de Pandas
    input_df = pd.DataFrame([input_dict])

    # --- Realizar la Predicción ---
    try:
        prediction = pipeline.predict(input_df)
        
        # Devuelve la predicción (el target es un int: 6, 8, 9, etc.)
        return {"predicted_quality_of_sleep": int(prediction[0])}

    except Exception as e:
        # Esto es útil para debuggear si falta una columna
        return {"error": f"Error durante la predicción: {str(e)}"}

# Endpoint de salud
@app.get("/health")
def health_check():
    return {"status": "ok" if pipeline is not None else "error", "model_loaded": pipeline is not None}