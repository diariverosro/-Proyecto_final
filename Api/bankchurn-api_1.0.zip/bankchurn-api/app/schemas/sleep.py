from pydantic import BaseModel
from typing import Optional

class SleepPredictionSchema(BaseModel):
    # Variables Categóricas
    Gender: str
    Occupation: str
    BMI_Category: str  # En el CSV original es "BMI Category"
    Sleep_Disorder: Optional[str] = "No Sleep Disorder"

    # Variables Numéricas
    Age: int
    Sleep_Duration: float
    Physical_Activity_Level: int
    Stress_Level: int
    Heart_Rate: int
    Daily_Steps: int
    Systolic_Pressure: int
    Diastolic_Pressure: int

    class Config:
        json_schema_extra = {
            "example": {
                "Gender": "Male",
                "Age": 32,
                "Occupation": "Engineer",
                "Sleep_Duration": 7.5,
                "Physical_Activity_Level": 60,
                "Stress_Level": 8,
                "BMI_Category": "Normal",
                "Heart_Rate": 70,
                "Daily_Steps": 8000,
                "Sleep_Disorder": "None",
                "Systolic_Pressure": 120,
                "Diastolic_Pressure": 80
            }
        }