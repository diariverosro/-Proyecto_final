import json
from typing import Any
from pathlib import Path # Importante para encontrar el archivo

import joblib # Importante para cargar el modelo
import numpy as np
import pandas as pd
from fastapi import APIRouter, HTTPException
from fastapi.encoders import jsonable_encoder
from loguru import logger

# Importaciones del modelo original (Bankchurn)
from model import __version__ as model_version
from model.predict import make_prediction

from app import __version__, schemas
from app.config import settings

# --- NUEVO: Importar el esquema de sueño ---
from app.schemas.sleep import SleepPredictionSchema

api_router = APIRouter()

# --- NUEVO: Cargar el modelo de Sueño al iniciar ---
# Buscamos el archivo .joblib en la misma carpeta que este script (api.py)
BASE_DIR = Path(__file__).resolve().parent
SLEEP_MODEL_PATH = BASE_DIR / "sleep_quality_svm_pipeline.joblib"

try:
    sleep_pipeline = joblib.load(SLEEP_MODEL_PATH)
    logger.info(f"Modelo de sueño cargado exitosamente desde: {SLEEP_MODEL_PATH}")
except Exception as e:
    logger.error(f"Error cargando el modelo de sueño: {e}")
    sleep_pipeline = None


# 1. Ruta de Salud (Existente)
@api_router.get("/health", response_model=schemas.Health, status_code=200)
def health() -> dict:
    """
    Root Get
    """
    health = schemas.Health(
        name=settings.PROJECT_NAME, api_version=__version__, model_version=model_version
    )
    return health.dict()


# 2. Ruta de Bankchurn (Existente)
@api_router.post("/predict", response_model=schemas.PredictionResults, status_code=200)
async def predict(input_data: schemas.MultipleDataInputs) -> Any:
    """
    Prediccion usando el modelo de bankchurn
    """
    input_df = pd.DataFrame(jsonable_encoder(input_data.inputs))

    logger.info(f"Making prediction on inputs: {input_data.inputs}")
    results = make_prediction(input_data=input_df.replace({np.nan: None}))

    if results["errors"] is not None:
        logger.warning(f"Prediction validation error: {results.get('errors')}")
        raise HTTPException(status_code=400, detail=json.loads(results["errors"]))

    logger.info(f"Prediction results: {results.get('predictions')}")

    return results


# 3. NUEVA RUTA: Predicción de Sueño
@api_router.post("/predict-sleep", status_code=200)
def predict_sleep_quality(payload: SleepPredictionSchema) -> Any:
    """
    Predicción de Calidad de Sueño usando SVM.
    """
    if not sleep_pipeline:
        raise HTTPException(status_code=500, detail="El modelo de sueño no se pudo cargar.")

    logger.info(f"Recibiendo datos de sueño: {payload}")

    # Convertimos el payload a DataFrame
    # IMPORTANTE: Mapear los nombres de Pydantic (con _) a los del modelo (con espacios)
    data = {
        'Gender': [payload.Gender],
        'Age': [payload.Age],
        'Occupation': [payload.Occupation],
        'Sleep Duration': [payload.Sleep_Duration],       # Mapeo clave
        'Physical Activity Level': [payload.Physical_Activity_Level], # Mapeo clave
        'Stress Level': [payload.Stress_Level],           # Mapeo clave
        'BMI Category': [payload.BMI_Category],           # Mapeo clave
        'Heart Rate': [payload.Heart_Rate],               # Mapeo clave
        'Daily Steps': [payload.Daily_Steps],             # Mapeo clave
        'Sleep Disorder': [payload.Sleep_Disorder],       # Mapeo clave
        'Systolic Pressure': [payload.Systolic_Pressure], # Mapeo clave
        'Diastolic Pressure': [payload.Diastolic_Pressure] # Mapeo clave
    }
    
    df_input = pd.DataFrame(data)

    try:
        # Predecir
        prediction = sleep_pipeline.predict(df_input)
        
        # Obtener probabilidades (Opcional, solo si probability=True en SVM)
        try:
            probs = sleep_pipeline.predict_proba(df_input).max()
            confidence = round(probs * 100, 2)
        except:
            confidence = "N/A"

        result = {
            "quality_of_sleep_prediction": int(prediction[0]) if isinstance(prediction[0], (np.int64, np.int32)) else str(prediction[0]),
            "confidence": f"{confidence}%"
        }
        
        logger.info(f"Predicción de sueño exitosa: {result}")
        return result

    except Exception as e:
        logger.error(f"Error durante la predicción de sueño: {e}")
        raise HTTPException(status_code=500, detail=f"Error interno del modelo: {str(e)}")
```

---

### Paso 4: Revisar `main.py`

Tu archivo `main.py` **está perfecto**. No necesitas cambiarle nada. Como `api_router` se importa desde `app.api`, y nosotros acabamos de agregar la ruta `/predict-sleep` a ese router, `main.py` la detectará automáticamente.

---

### Paso 5: Probar

1.  Asegúrate de tener las librerías instaladas:
    ```bash
    pip install scikit-learn pandas joblib fastapi uvicorn
    ```
2.  Ejecuta tu servidor desde la terminal (estando en la carpeta raíz `bankchurn-api`):
    ```bash
    python -m uvicorn app.main:app --reload