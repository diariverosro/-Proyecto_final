#!/bin/bash
export PYTHONPATH=$PYTHONPATH:/app

# Usa el puerto de la nube ($PORT) o 8001 por defecto
PORT=${PORT:-8001}

exec uvicorn app.main:app --host 0.0.0.0 --port $PORT
