import json
from typing import Any
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
from fastapi import APIRouter, HTTPException
from fastapi.encoders import jsonable_encoder
from loguru import logger

# Modelos anteriores
from model import __version__ as model_version
from model.predict import make_prediction
from app import __version__, schemas
from app.config import settings

# Schema de Sueño
from app.schemas.sleep import SleepPredictionSchema

api_router = APIRouter()

# --- CARGA DEL MODELO DE REGRESIÓN (Gradient Boosting) ---
BASE_DIR = Path(__file__).resolve().parent
SLEEP_MODEL_PATH = BASE_DIR / "sleep_gradient_boosting_pipeline.joblib"

try:
    sleep_pipeline = joblib.load(SLEEP_MODEL_PATH)
    logger.info(f"Pipeline de Regresión cargado: {SLEEP_MODEL_PATH}")
except Exception as e:
    logger.error(f"Error cargando modelo sueño: {e}")
    sleep_pipeline = None

# 1. Ruta Health (OCULTA: include_in_schema=False)
@api_router.get("/health", response_model=schemas.Health, status_code=200, include_in_schema=False)
def health() -> dict:
    return schemas.Health(name=settings.PROJECT_NAME, api_version=__version__, model_version=model_version).dict()

# 2. Ruta Bankchurn (OCULTA: include_in_schema=False) -> ¡ESTE ES EL QUE QUERÍAS QUITAR!
@api_router.post("/predict", response_model=schemas.PredictionResults, status_code=200, include_in_schema=False)
async def predict(input_data: schemas.MultipleDataInputs) -> Any:
    input_df = pd.DataFrame(jsonable_encoder(input_data.inputs))
    results = make_prediction(input_data=input_df.replace({np.nan: None}))
    if results["errors"]:
        raise HTTPException(status_code=400, detail=json.loads(results["errors"]))
    return results

# 3. Ruta Sueño (VISIBLE - Esta es la única que aparecerá)
@api_router.post("/predict-sleep", status_code=200)
def predict_sleep_quality(payload: SleepPredictionSchema) -> Any:
    if not sleep_pipeline:
        raise HTTPException(status_code=500, detail="Modelo no disponible")
    
    data = {
        'Gender': [payload.Gender], 'Age': [payload.Age],
        'Occupation': [payload.Occupation], 'Sleep Duration': [payload.Sleep_Duration],
        'Physical Activity Level': [payload.Physical_Activity_Level],
        'Stress Level': [payload.Stress_Level], 'BMI Category': [payload.BMI_Category],
        'Heart Rate': [payload.Heart_Rate], 'Daily Steps': [payload.Daily_Steps],
        'Sleep Disorder': [payload.Sleep_Disorder],
        'Systolic Pressure': [payload.Systolic_Pressure],
        'Diastolic Pressure': [payload.Diastolic_Pressure]
    }
    
    try:
        # 1. Convertir a DataFrame
        df_input = pd.DataFrame(data)
        
        # 2. Predecir (Regresión devuelve un número continuo)
        prediction = sleep_pipeline.predict(df_input)
        predicted_score = float(prediction[0])
        
        # 3. Interpretación simple
        quality_label = "Buena" if predicted_score >= 7.0 else "Mala"

        return {
            "quality_of_sleep_score": round(predicted_score, 2),
            "interpretation": quality_label,
            "model_type": "Gradient Boosting Regressor"
        }

    except Exception as e:
        logger.error(f"Error predicción sueño: {e}")
        if "could not convert string to float" in str(e):
             raise HTTPException(status_code=500, detail="Error: El pipeline no incluye el preprocesador. Asegúrate de guardar el pipeline completo.")
        raise HTTPException(status_code=500, detail=str(e))