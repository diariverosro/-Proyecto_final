import dash
from dash import dcc, html
from dash.dependencies import Input, Output, State
import requests # Para llamar a tu API

app = dash.Dash(__name__)

# --- 1. Define la Interfaz (Los Controles) ---
app.layout = html.Div(style={'padding': '20px'}, children=[
    html.H1("Simulador de Calidad de Sueño"),

    html.Div(style={'display': 'grid', 'gridTemplateColumns': '1fr 1fr', 'gap': '10px'}, children=[
        dcc.Input(id='age-input', placeholder='Edad (ej. 27)', type='number'),
        dcc.Input(id='occupation-input', placeholder='Ocupación (ej. Software Engineer)', type='text'),
        dcc.Input(id='sleep-duration-input', placeholder='Duración Sueño (ej. 6.1)', type='number'),
        dcc.Input(id='activity-input', placeholder='Nivel Act. Física (ej. 42)', type='number'),
        dcc.Input(id='stress-input', placeholder='Nivel Estrés (ej. 6)', type='number'),
        dcc.Input(id='bmi-input', placeholder='Categoría BMI (ej. Overweight)', type='text'),
        dcc.Input(id='bp-input', placeholder='Presión (ej. 126/83)', type='text'),
        dcc.Input(id='hr-input', placeholder='Ritmo Cardíaco (ej. 77)', type='number'),
        dcc.Input(id='steps-input', placeholder='Pasos Diarios (ej. 4200)', type='number'),
        dcc.Input(id='disorder-input', placeholder='Desorden (ej. None)', type='text'),
        dcc.Input(id='gender-input', placeholder='Género (ej. Male)', type='text'),
    ]),
    
    html.Br(),
    html.Button('Simular Predicción', id='predict-button', n_clicks=0),
    html.Hr(),
    html.H2("Resultado:"),
    html.Div(id='prediction-output', style={'fontSize': '24px', 'fontWeight': 'bold'})
])

# --- 2. Define la Interactividad (El Callback) ---
@app.callback(
    Output('prediction-output', 'children'),
    Input('predict-button', 'n_clicks'),
    [
        # Recoge el valor de CADA uno de tus controles
        State('gender-input', 'value'),
        State('age-input', 'value'),
        State('occupation-input', 'value'),
        State('sleep-duration-input', 'value'),
        State('activity-input', 'value'),
        State('stress-input', 'value'),
        State('bmi-input', 'value'),
        State('bp-input', 'value'),
        State('hr-input', 'value'),
        State('steps-input', 'value'),
        State('disorder-input', 'value')
    ]
)
def update_prediction(n_clicks, gender, age, occupation, sleep_dur, activity, stress, bmi, bp, hr, steps, disorder):
    if n_clicks == 0:
        return "Complete los campos y presione 'Simular'."

    # 3. Construye el JSON para tu API
    #    (Pydantic es sensible a mayúsculas y espacios, ¡usa los nombres exactos!)
    api_payload = {
        "Gender": gender,
        "Age": age,
        "Occupation": occupation,
        "Sleep Duration": sleep_dur,
        "Physical Activity Level": activity,
        "Stress Level": stress,
        "BMI Category": bmi,
        "Blood Pressure": bp,
        "Heart Rate": hr,
        "Daily Steps": steps,
        # Maneja el caso nulo
        "Sleep Disorder": None if disorder in [None, "None", ""] else disorder
    }

    try:
        # 4. LLAMA A TU API DE FASTAPI
        #    Usamos 'localhost:8000' porque ambas apps corren en la misma máquina EC2
        api_url = "http://localhost:8000/predict"
        response = requests.post(api_url, json=api_payload)

        if response.status_code == 200:
            # 5. Muestra el resultado
            prediction = response.json()['predicted_quality_of_sleep']
            return f"Calidad de Sueño Predicha: {prediction}"
        else:
            # Muestra el error de validación de Pydantic
            return f"Error de la API: {response.text}"
            
    except Exception as e:
        return f"Error de conexión: No se pudo conectar a la API en {api_url}. ¿Está corriendo? {str(e)}"

# --- 4. Corre el servidor de Dash ---
if __name__ == '__main__':
    # Lo corremos en un puerto DIFERENTE (ej. 8050)
    app.run_server(debug=True, host='0.0.0.0', port=8050)